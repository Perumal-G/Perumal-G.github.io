# Perumal G — Graphic Designer Portfolio

Static portfolio prepared for free GitHub Pages hosting. The contact form prepares an email draft and does not store submissions.

Copyright Perumal G. Third-party icon license: assets/licenses/lucide.txt.
