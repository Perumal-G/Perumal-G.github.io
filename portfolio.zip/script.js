/* Portfolio interactions — plain JavaScript, no build tools or external services. */
(() => {
  'use strict';

  // CHANGE CONTACT DETAILS HERE. Keep the matching details in index.html up to date
  // so contact links also work when JavaScript is unavailable.
  const CONTACT = {
    email: 'deepu.alone92@gmail.com',
    phone: '+91 63624 68629',
    name: 'Perumal G',
    location: 'Koramangala, Bangalore, India'
  };

  const initialize = () => {
    const body = document.body;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const telephone = CONTACT.phone.replace(/[^\d+]/g, '');
    document.querySelectorAll('[data-email-link]').forEach(link => {
      link.href = `mailto:${CONTACT.email}`;
    });
    document.querySelectorAll('[data-phone-link]').forEach(link => {
      link.href = `tel:${telephone}`;
    });
    document.querySelectorAll('[data-email-text]').forEach(element => {
      element.textContent = CONTACT.email;
    });
    document.querySelectorAll('[data-phone-text]').forEach(element => {
      element.textContent = CONTACT.phone;
    });
    const year = document.getElementById('current-year');
    if (year) year.textContent = String(new Date().getFullYear());

    /* The mobile overlay keeps ordinary anchor links and restores the reading position. */
    const menuToggle = document.getElementById('menu-toggle');
    const navigation = document.getElementById('site-nav');
    const desktopNavigation = window.matchMedia('(min-width: 1001px)');
    let menuScroll;
    let menuBodyStyles;
    const menuBackground = [...document.querySelectorAll('main, .site-footer, .skip-link')];
    const inertBeforeMenu = new Map();
    const lockMenuScroll = () => {
      if (menuScroll) return;
      menuScroll = { x: window.scrollX, y: window.scrollY };
      const properties = ['position', 'top', 'left', 'right', 'width', 'overflow', 'padding-right'];
      menuBodyStyles = new Map(properties.map(property => [property, {
        value: body.style.getPropertyValue(property), priority: body.style.getPropertyPriority(property)
      }]));
      const scrollbar = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
      if (scrollbar) {
        const padding = parseFloat(window.getComputedStyle(body).paddingRight) || 0;
        body.style.setProperty('padding-right', `${padding + scrollbar}px`);
      }
      body.style.setProperty('position', 'fixed');
      body.style.setProperty('top', `${-menuScroll.y}px`);
      body.style.setProperty('left', '0');
      body.style.setProperty('right', '0');
      body.style.setProperty('width', '100%');
      body.style.setProperty('overflow', 'hidden');
      menuBackground.forEach(element => {
        inertBeforeMenu.set(element, element.inert);
        element.inert = true;
      });
    };
    const unlockMenuScroll = () => {
      if (!menuScroll) return;
      const position = menuScroll;
      menuBodyStyles.forEach(({ value, priority }, property) => {
        if (value) body.style.setProperty(property, value, priority);
        else body.style.removeProperty(property);
      });
      inertBeforeMenu.forEach((inert, element) => { element.inert = inert; });
      inertBeforeMenu.clear();
      menuScroll = null;
      menuBodyStyles = null;
      // Avoid a smooth-scroll detour before the selected anchor runs its native action.
      window.scrollTo({ left: position.x, top: position.y, behavior: 'instant' });
    };
    const setMenu = (open, restoreFocus = true) => {
      if (!menuToggle || !navigation) return;
      open = Boolean(open && !desktopNavigation.matches);
      const wasOpen = menuToggle.getAttribute('aria-expanded') === 'true';
      if (open === wasOpen) return;
      if (open) lockMenuScroll();
      menuToggle.setAttribute('aria-expanded', String(open));
      menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      navigation.classList.toggle('is-open', open);
      body.classList.toggle('menu-open', open);
      if (open) {
        const firstLink = navigation.querySelector('a[href]');
        if (firstLink) firstLink.focus({ preventScroll: true });
      } else {
        unlockMenuScroll();
        if (restoreFocus) menuToggle.focus({ preventScroll: true });
      }
    };
    if (menuToggle && navigation) {
      document.documentElement.classList.add('js-nav');
      menuToggle.addEventListener('click', () => {
        setMenu(menuToggle.getAttribute('aria-expanded') !== 'true');
      });
      navigation.addEventListener('click', event => {
        const link = event.target.closest('a');
        if (!link || !navigation.contains(link)) return;
        setMenu(false, false);
        const destination = link.hash && document.getElementById(link.hash.slice(1));
        if (destination && event.detail === 0) {
          const hadTabIndex = destination.hasAttribute('tabindex');
          if (!hadTabIndex) destination.setAttribute('tabindex', '-1');
          destination.focus({ preventScroll: true });
          if (!hadTabIndex) destination.addEventListener('blur', () => destination.removeAttribute('tabindex'), { once: true });
        } else {
          menuToggle.focus({ preventScroll: true });
        }
      });
      document.addEventListener('click', event => {
        if (!navigation.contains(event.target) && !menuToggle.contains(event.target)) {
          setMenu(false);
        }
      });
      document.addEventListener('keydown', event => {
        if (menuToggle.getAttribute('aria-expanded') !== 'true') return;
        if (event.key === 'Escape') {
          event.preventDefault();
          setMenu(false);
        } else if (event.key === 'Tab') {
          const focusable = [menuToggle, ...navigation.querySelectorAll('a[href], button:not([disabled])')]
            .filter(element => !element.hidden && element.getClientRects().length);
          const first = focusable[0];
          const last = focusable[focusable.length - 1];
          if (event.shiftKey && (document.activeElement === first || !focusable.includes(document.activeElement))) {
            event.preventDefault();
            if (last) last.focus();
          } else if (!event.shiftKey && (document.activeElement === last || !focusable.includes(document.activeElement))) {
            event.preventDefault();
            if (first) first.focus();
          }
        }
      });
      const resetAtDesktop = event => { if (event.matches) setMenu(false, false); };
      if (desktopNavigation.addEventListener) desktopNavigation.addEventListener('change', resetAtDesktop);
      else desktopNavigation.addListener(resetAtDesktop);
    }

    /* Reveal is opt-in; content stays readable if JavaScript or observation fails. */
    const revealElements = [...document.querySelectorAll('.reveal')];
    const showAllReveals = () => {
      revealElements.forEach(element => element.classList.add('is-visible'));
    };
    let revealObserver;
    if (!reducedMotion.matches && 'IntersectionObserver' in window) {
      try {
        revealObserver = new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          });
        }, { threshold: 0.08, rootMargin: '0px 0px 35px 0px' });
        revealElements.forEach(element => revealObserver.observe(element));
        document.documentElement.classList.add('js-reveal');
      } catch (_) {
        showAllReveals();
      }
    } else {
      showAllReveals();
    }
    const motionChanged = event => {
      if (!event.matches) return;
      if (revealObserver) revealObserver.disconnect();
      showAllReveals();
    };
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', motionChanged);
    else reducedMotion.addListener(motionChanged);

    /* Responsibilities retain native details semantics and stay exclusive when expanded. */
    const responsibilities = [...document.querySelectorAll('#experience .career-responsibilities')].map(details => {
      const summary = details.querySelector('summary');
      if (!summary) return null;
      let content = details.querySelector('.responsibilities-content');
      if (!content) {
        content = document.createElement('div');
        content.className = 'responsibilities-content';
        [...details.childNodes].filter(node => node !== summary).forEach(node => content.append(node));
        details.append(content);
      }
      summary.setAttribute('aria-expanded', String(details.open));
      return { details, summary, content, animation: null, expanded: details.open,
        originalOverflow: details.style.getPropertyValue('overflow'),
        overflowPriority: details.style.getPropertyPriority('overflow') };
    }).filter(Boolean);
    const finishResponsibilities = state => {
      if (state.animation) state.animation.cancel();
      state.animation = null;
      state.details.open = state.expanded;
      state.summary.setAttribute('aria-expanded', String(state.expanded));
      if (state.originalOverflow) state.details.style.setProperty('overflow', state.originalOverflow, state.overflowPriority);
      else state.details.style.removeProperty('overflow');
      state.details.classList.remove('is-animating');
    };
    const setResponsibilities = (state, expanded) => {
      if (state.expanded === expanded && !state.animation) return;
      const startHeight = state.details.getBoundingClientRect().height;
      if (state.animation) state.animation.cancel();
      state.animation = null;
      state.expanded = expanded;
      state.summary.setAttribute('aria-expanded', String(expanded));
      if (reducedMotion.matches || typeof state.details.animate !== 'function') {
        finishResponsibilities(state);
        return;
      }
      state.details.open = expanded;
      const endHeight = state.details.getBoundingClientRect().height;
      // Keep the panel present while collapsing; it closes after its final frame.
      state.details.open = true;
      state.details.style.setProperty('overflow', 'hidden');
      state.details.classList.add('is-animating');
      const animation = state.details.animate([
        { height: `${startHeight}px` }, { height: `${endHeight}px` }
      ], { duration: 280, easing: 'cubic-bezier(.22,.68,.2,1)', fill: 'both' });
      state.animation = animation;
      animation.finished.then(() => {
        if (state.animation === animation) finishResponsibilities(state);
      }).catch(() => { /* A newer selection or motion preference owns the final state. */ });
    };
    let firstExpanded = false;
    responsibilities.forEach(state => {
      if (state.expanded && firstExpanded) {
        state.expanded = false;
        finishResponsibilities(state);
      } else if (state.expanded) firstExpanded = true;
      state.summary.addEventListener('click', event => {
        event.preventDefault();
        const expanded = !state.expanded;
        if (expanded) responsibilities.forEach(other => { if (other !== state) setResponsibilities(other, false); });
        setResponsibilities(state, expanded);
      });
      state.details.addEventListener('toggle', () => {
        if (state.animation) return;
        state.expanded = state.details.open;
        state.summary.setAttribute('aria-expanded', String(state.expanded));
        if (state.expanded) responsibilities.forEach(other => { if (other !== state) setResponsibilities(other, false); });
      });
    });
    const finishAccordionsForReducedMotion = event => {
      if (event.matches) responsibilities.forEach(finishResponsibilities);
    };
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', finishAccordionsForReducedMotion);
    else reducedMotion.addListener(finishAccordionsForReducedMotion);

    /* The workflow line draws once, only when this small section comes into view. */
    const workflow = document.querySelectorAll('.working-process')[0];
    let workflowObserver;
    const showWorkflow = () => {
      if (workflow) workflow.classList.add('is-visible');
      if (workflowObserver) workflowObserver.disconnect();
    };
    if (workflow && !reducedMotion.matches && 'IntersectionObserver' in window) {
      try {
        workflowObserver = new IntersectionObserver(entries => {
          if (entries.some(entry => entry.isIntersecting)) showWorkflow();
        }, { threshold: 0.2 });
        workflowObserver.observe(workflow);
      } catch (_) { showWorkflow(); }
    } else showWorkflow();
    const workflowMotionChanged = event => { if (event.matches) showWorkflow(); };
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', workflowMotionChanged);
    else reducedMotion.addListener(workflowMotionChanged);

    const navLinks = [...document.querySelectorAll('#site-nav .nav-link[href^="#"]')];
    const navSections = navLinks.map(link => {
      const section = document.getElementById(link.hash.slice(1));
      return section ? { link, section } : null;
    }).filter(Boolean).sort((first, second) => {
      if (first.section === second.section) return 0;
      return first.section.compareDocumentPosition(second.section) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
    const activateSection = sectionId => {
      navSections.forEach(({ link, section }) => {
        const active = section.id === sectionId;
        link.classList.toggle('is-active', active);
        if (active) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    };
    if (navSections.length) {
      activateSection(location.hash.slice(1) || navSections[0].section.id);
      let scrollPending = false;
      const updateActiveSection = () => {
        let active = navSections[0].section;
        const readingLine = Math.min(window.innerHeight * 0.3, 220);
        navSections.forEach(({ section }) => {
          if (section.getBoundingClientRect().top <= readingLine) active = section;
        });
        if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 8) {
          active = navSections[navSections.length - 1].section;
        }
        activateSection(active.id);
        scrollPending = false;
      };
      const queueActiveSection = () => {
        if (scrollPending) return;
        scrollPending = true;
        window.requestAnimationFrame(updateActiveSection);
      };
      window.addEventListener('scroll', queueActiveSection, { passive: true });
      window.addEventListener('resize', queueActiveSection, { passive: true });
      updateActiveSection();
    }

    /* ADD NEW PORTFOLIO PROJECT HERE: edit the array in projects.js. */
    const projects = Array.isArray(window.PORTFOLIO_PROJECTS) ? window.PORTFOLIO_PROJECTS : [];
    const grid = document.getElementById('project-grid');
    const projectCount = document.getElementById('project-count');
    const filterBar = document.getElementById('project-filters');
    const expandButton = document.getElementById('project-expand');
    const preferredProjectIds = ['project-01', 'project-04', 'project-08', 'project-05'];
    // The compact opening keeps production strengths first without renumbering work.
    const orderedProjects = [
      ...preferredProjectIds.map(id => projects.find(project => String(project.id) === id)).filter(Boolean),
      ...projects.filter(project => !preferredProjectIds.includes(String(project.id)))
    ];
    const previewProjectIds = new Set(orderedProjects.slice(0, 4).map(project => String(project.id)));
    const cards = [];
    const makeElement = (tag, className, text) => {
      const element = document.createElement(tag);
      if (className) element.className = className;
      if (text !== undefined) element.textContent = String(text);
      return element;
    };
    const arrowIcon = () => {
      const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      icon.setAttribute('class', 'icon');
      icon.setAttribute('aria-hidden', 'true');
      icon.setAttribute('viewBox', '0 0 24 24');
      const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      use.setAttribute('href', '#i-arrow');
      icon.append(use);
      return icon;
    };
    const filterLabel = filter => {
      const button = filterBar && [...filterBar.querySelectorAll('button[data-filter]')]
        .find(item => item.dataset.filter === filter);
      return filter === 'all' ? '' : (button ? button.textContent.trim() : '');
    };
    const setCount = (count, view = { filter: 'all', expanded: false }) => {
      if (projectCount) {
        const allSamples = projects.every(project => project.placeholder !== false);
        const kind = allSamples ? 'Exploration' : 'Project';
        if (view.filter === 'all' && !view.expanded && count < projects.length) {
          projectCount.textContent = `${String(count).padStart(2, '0')} of ${String(projects.length).padStart(2, '0')} ${kind.toLowerCase()}s`;
          return;
        }
        const category = filterLabel(view.filter);
        projectCount.textContent = `${String(count).padStart(2, '0')} ${category ? `${category} ` : ''}${kind}${count === 1 ? '' : 's'}`;
      }
    };
    const syncExpansion = view => {
      if (!expandButton) return;
      expandButton.hidden = view.filter !== 'all' || projects.length <= previewProjectIds.size;
      expandButton.type = 'button';
      expandButton.setAttribute('aria-controls', 'project-grid');
      expandButton.setAttribute('aria-expanded', String(view.filter === 'all' && view.expanded));
      expandButton.textContent = view.expanded ? 'Show fewer projects' : `Show all ${projects.length} projects`;
    };
    if (grid && projects.length) {
      const fragment = document.createDocumentFragment();
      orderedProjects.forEach(project => {
        const index = projects.indexOf(project);
        const card = makeElement('article', `project-card${project.featured ? ' is-featured' : ''}`);
        card.dataset.projectId = String(project.id);
        card.hidden = !previewProjectIds.has(String(project.id));
        const button = makeElement('button', 'project-open');
        button.type = 'button';
        button.dataset.projectId = String(project.id);
        button.setAttribute('aria-label', `View ${project.title}`);
        button.setAttribute('aria-haspopup', 'dialog');
        const imageWrap = makeElement('span', 'project-image-wrap');
        const picture = makeElement('img', 'project-image');
        picture.src = project.image;
        picture.alt = project.imageAlt || `${project.title}${project.placeholder === false ? '' : ' placeholder'} artwork`;
        picture.width = project.imageWidth || 1448;
        picture.height = project.imageHeight || 1086;
        picture.loading = 'lazy';
        picture.decoding = 'async';
        const overlay = makeElement('span', 'project-overlay', 'View details');
        overlay.append(arrowIcon());
        overlay.setAttribute('aria-hidden', 'true');
        const viewCursor = makeElement('span', 'project-view-cursor', 'VIEW');
        viewCursor.setAttribute('aria-hidden', 'true');
        imageWrap.append(picture, overlay, viewCursor);
        if (project.featured) {
          imageWrap.append(makeElement('span', 'project-featured-label', project.placeholder === false ? 'FEATURED PROJECT' : 'FEATURED EXPLORATION'));
        }
        const info = makeElement('span', 'project-info');
        const category = makeElement('span', 'project-category', project.category);
        const number = makeElement('span', 'project-index', `${String(index + 1).padStart(2, '0')} / ${String(projects.length).padStart(2, '0')}`);
        number.setAttribute('aria-hidden', 'true');
        const title = makeElement('span', 'project-title', project.title);
        info.append(number, category, title);
        const summary = String(project.description || '')
          .replace(/^Illustrative concept mockup:\s*/i, '').trim();
        if (summary) info.append(makeElement('span', 'project-summary', summary));
        const medium = project.medium || project.format || (Array.isArray(project.software) ? project.software.join(' / ') : project.software);
        if (medium) info.append(makeElement('span', 'project-meta', medium));
        // Set placeholder: false in projects.js when adding completed work.
        if (project.placeholder !== false) {
          info.append(makeElement('span', 'project-sample-label', 'Concept study'));
        }
        const cta = makeElement('span', 'project-card-cta', 'View details');
        cta.append(arrowIcon());
        info.append(cta);
        button.append(imageWrap, info);
        card.append(button);
        fragment.append(card);
        cards.push({ card, project });
      });
      grid.replaceChildren(fragment);
      grid.dataset.filter = 'all';
      grid.dataset.expanded = 'false';
      grid.classList.add('is-collapsed');
      setCount(previewProjectIds.size);
      syncExpansion({ filter: 'all', expanded: false });
    }

    /* Cards reveal once; CSS hides them only after observation is available. */
    let cardObserver;
    const revealAllCards = () => {
      if (cardObserver) cardObserver.disconnect();
      cards.forEach(({ card }) => {
        card.style.setProperty('--card-reveal-delay', '0ms');
        card.classList.add('is-card-visible');
      });
    };
    if (grid && cards.length && !reducedMotion.matches && 'IntersectionObserver' in window) {
      try {
        cardObserver = new IntersectionObserver(entries => {
          const incoming = entries.filter(entry => entry.isIntersecting && !entry.target.hidden)
            .sort((first, second) => cards.findIndex(item => item.card === first.target) - cards.findIndex(item => item.card === second.target));
          incoming.forEach((entry, index) => {
            entry.target.style.setProperty('--card-reveal-delay', `${(index % 3) * 60}ms`);
            entry.target.classList.add('is-card-visible');
            cardObserver.unobserve(entry.target);
          });
        }, { threshold: 0.08, rootMargin: '0px 0px 30px 0px' });
        cards.forEach(({ card }) => cardObserver.observe(card));
        grid.classList.add('has-card-reveals');
      } catch (_) {
        revealAllCards();
      }
    } else {
      revealAllCards();
    }

    let requestedView = { filter: 'all', expanded: false };
    let appliedView = { filter: 'all', expanded: false };
    let filterTransition;
    const matchesView = (project, view) => {
      if (view.filter !== 'all') return (project.categories || []).includes(view.filter);
      return view.expanded || previewProjectIds.has(String(project.id));
    };
    const filterEvent = (name, view) => {
      if (grid) grid.dispatchEvent(new CustomEvent(name, { bubbles: true, detail: { ...view } }));
    };
    const finishFilterTransition = () => {
      const previous = filterTransition;
      if (!previous) return;
      filterTransition = null;
      previous.animations.forEach(animation => animation.cancel());
      grid.classList.remove('is-filtering');
      grid.removeAttribute('aria-busy');
      filterEvent('portfolio:filterend', appliedView);
    };
    const applyView = view => {
      let count = 0;
      cards.forEach(({ card, project }) => {
        const visible = matchesView(project, view);
        card.hidden = !visible;
        card.classList.toggle('is-featured', view.filter === 'all' && Boolean(project.featured));
        const featuredLabel = card.querySelector('.project-featured-label');
        if (featuredLabel) featuredLabel.hidden = view.filter !== 'all';
        if (visible) {
          count += 1;
          // Filtering is its own reveal; scroll effects must not hide new matches.
          if (cardObserver) cardObserver.unobserve(card);
          card.style.setProperty('--card-reveal-delay', '0ms');
          card.classList.add('is-card-visible');
        }
      });
      grid.dataset.filter = view.filter;
      grid.dataset.filterLabel = filterLabel(view.filter);
      grid.dataset.expanded = String(view.filter === 'all' && view.expanded);
      grid.classList.toggle('is-collapsed', view.filter === 'all' && !view.expanded);
      appliedView = { ...view };
      setCount(count, view);
      syncExpansion(view);
    };
    const animateView = async view => {
      finishFilterTransition();
      if (view.filter === appliedView.filter && view.expanded === appliedView.expanded) return;
      if (reducedMotion.matches || !cards.every(({ card }) => typeof card.animate === 'function')) {
        filterEvent('portfolio:filterstart', view);
        applyView(view);
        filterEvent('portfolio:filterend', view);
        return;
      }
      const transition = { animations: [] };
      filterTransition = transition;
      grid.classList.add('is-filtering');
      grid.setAttribute('aria-busy', 'true');
      filterEvent('portfolio:filterstart', view);
      const easing = 'cubic-bezier(.22,.68,.2,1)';
      const animate = (card, keyframes, options) => {
        const animation = card.animate(keyframes, options);
        transition.animations.push(animation);
        return animation.finished.catch(() => {});
      };
      const oldCards = cards.filter(({ card }) => !card.hidden);
      const outgoing = oldCards.filter(({ project }) => !matchesView(project, view));
      await Promise.all(outgoing.map(({ card }) => animate(card, [
        { opacity: 1, transform: 'scale(1)' },
        { opacity: 0, transform: 'scale(.975)' }
      ], { duration: 110, easing, fill: 'forwards' })));
      if (filterTransition !== transition) return;
      const oldRects = new Map(oldCards.map(({ card }) => [card, card.getBoundingClientRect()]));
      applyView(view);
      const visible = cards.filter(({ card }) => !card.hidden);
      // All layout reads happen together before the transform animations begin.
      const newRects = new Map(visible.map(({ card }) => [card, card.getBoundingClientRect()]));
      const incoming = visible.filter(({ card }) => !oldRects.has(card));
      const movement = visible.filter(({ card }) => oldRects.has(card));
      const promises = movement.map(({ card }) => {
        const first = oldRects.get(card);
        const last = newRects.get(card);
        const dx = first.left - last.left;
        const dy = first.top - last.top;
        const sx = last.width ? first.width / last.width : 1;
        const sy = last.height ? first.height / last.height : 1;
        return animate(card, [
          { transform: `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})`, transformOrigin: 'top left' },
          { transform: 'translate(0px, 0px) scale(1, 1)', transformOrigin: 'top left' }
        ], { duration: 330, easing });
      });
      incoming.forEach(({ card }, index) => {
        promises.push(animate(card, [
          { opacity: 0, transform: 'translateY(12px) scale(.98)' },
          { opacity: 1, transform: 'translateY(0px) scale(1)' }
        ], { duration: 260, delay: (index % 3) * 40, easing, fill: 'backwards' }));
      });
      await Promise.all(promises);
      if (filterTransition === transition) finishFilterTransition();
    };
    const requestView = view => {
      requestedView = { ...view };
      // The button announces the requested state while the short transition settles.
      syncExpansion(requestedView);
      animateView(requestedView).catch(() => {
        finishFilterTransition();
        applyView(requestedView);
      });
    };
    if (filterBar && cards.length) {
      filterBar.addEventListener('click', event => {
        const clicked = event.target.closest('button[data-filter]');
        if (!clicked || !filterBar.contains(clicked)) return;
        const filter = clicked.dataset.filter;
        filterBar.querySelectorAll('button[data-filter]').forEach(button => {
          const selected = button === clicked;
          button.setAttribute('aria-pressed', String(selected));
          button.classList.toggle('is-active', selected);
        });
        const barBox = filterBar.getBoundingClientRect();
        const buttonBox = clicked.getBoundingClientRect();
        if (filterBar.scrollWidth > filterBar.clientWidth && (buttonBox.left < barBox.left || buttonBox.right > barBox.right)) {
          clicked.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: reducedMotion.matches ? 'auto' : 'smooth' });
        }
        // Returning to All starts the concise four-project opening again.
        requestView({ filter, expanded: false });
      });
    }
    if (expandButton && cards.length) {
      expandButton.addEventListener('click', () => {
        if (requestedView.filter !== 'all') return;
        requestView({ filter: 'all', expanded: !requestedView.expanded });
      });
    }
    const galleryMotionChanged = event => {
      if (!event.matches) return;
      revealAllCards();
      finishFilterTransition();
      if (grid && cards.length) applyView(requestedView);
    };
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', galleryMotionChanged);
    else reducedMotion.addListener(galleryMotionChanged);

    /* Native dialog supplies a focus trap, Escape dismissal and background inertness. */
    const dialog = document.getElementById('project-dialog');
    const closeButton = document.getElementById('dialog-close');
    const fullImageButton = document.getElementById('dialog-full-image');
    const fullImageLabel = document.getElementById('dialog-full-image-label');
    const primaryImage = document.getElementById('dialog-image');
    const setImageRatio = (width, height) => {
      const ratio = Number(width) / Number(height);
      if (dialog && Number.isFinite(ratio) && ratio > 0) dialog.style.setProperty('--dialog-image-ratio', String(ratio));
    };
    if (primaryImage) primaryImage.addEventListener('load', () => setImageRatio(primaryImage.naturalWidth, primaryImage.naturalHeight));
    const setProjectImage = (image, alt) => {
      if (!primaryImage) return;
      const width = image.width || 1448;
      const height = image.height || 1086;
      setImageRatio(width, height);
      primaryImage.width = width;
      primaryImage.height = height;
      primaryImage.alt = image.alt || alt;
      primaryImage.src = image.src;
    };
    const setFullImageView = expanded => {
      if (!dialog) return;
      dialog.classList.toggle('is-image-only', expanded);
      if (fullImageButton) fullImageButton.setAttribute('aria-expanded', String(expanded));
      if (fullImageLabel) fullImageLabel.textContent = expanded ? 'Back to details' : 'View full image';
    };
    if (fullImageButton) fullImageButton.addEventListener('click', () => {
      setFullImageView(!dialog.classList.contains('is-image-only'));
      dialog.scrollTop = 0;
    });
    let modalTrigger;
    const field = (id, value) => {
      const element = document.getElementById(id);
      if (element) element.textContent = value || 'Details will be added with the final project.';
    };
    const imageDetails = image => typeof image === 'string' ? { src: image } : image;
    const productionFields = project => {
      if (Array.isArray(project.production)) {
        return project.production.filter(item => item && item.label && item.value);
      }
      if (project.production && typeof project.production === 'object') {
        return Object.entries(project.production).map(([label, value]) => ({ label, value })).filter(item => item.value);
      }
      return [
        { label: 'Medium', value: project.medium },
        { label: 'Production approach', value: project.productionMethod },
        { label: 'Materials', value: project.materials },
        { label: 'Format', value: project.format }
      ].filter(item => item.value);
    };
    const safeStudyUrl = value => {
      if (typeof value !== 'string' || !value.trim()) return '';
      try {
        const url = new URL(value, location.href);
        const sameSite = url.origin === location.origin;
        const readableProtocol = /^https?:$/.test(url.protocol) || (url.protocol === 'file:' && location.protocol === 'file:');
        return sameSite && readableProtocol ? url.href : '';
      } catch (_) {
        return '';
      }
    };
    const showProject = (project, trigger) => {
      if (!dialog) return;
      setFullImageView(false);
      modalTrigger = trigger;
      const isPlaceholder = project.placeholder !== false;
      field('dialog-title', project.title);
      field('dialog-category', `${project.category}${isPlaceholder ? ' · Illustrative mockup' : ''}`);
      const placeholderLabel = dialog.querySelector('.dialog-placeholder-label');
      if (placeholderLabel) placeholderLabel.hidden = !isPlaceholder;
      field('dialog-description', project.description);
      field('dialog-challenge', project.challenge);
      field('dialog-solution', project.solution);
      field('dialog-software', Array.isArray(project.software) ? project.software.join(' · ') : project.software);
      field('dialog-output', project.output);
      const dialogCopy = dialog.querySelector('.dialog-copy');
      if (dialogCopy) {
        let production = dialogCopy.querySelector('.dialog-production-details');
        if (!production) {
          production = makeElement('dl', 'project-details dialog-production-details');
          dialogCopy.append(production);
        }
        production.replaceChildren();
        const details = productionFields(project);
        details.forEach(({ label, value }) => {
          const row = makeElement('div');
          row.append(makeElement('dt', '', label), makeElement('dd', '', Array.isArray(value) ? value.join(' · ') : value));
          production.append(row);
        });
        production.hidden = !details.length;
        let studyLink = dialogCopy.querySelector('.dialog-study-link');
        if (!studyLink) {
          studyLink = makeElement('a', 'button button-outline dialog-study-link');
          dialogCopy.append(studyLink);
        }
        const studyUrl = safeStudyUrl(project.caseStudy);
        studyLink.hidden = !studyUrl;
        if (studyUrl) {
          studyLink.href = studyUrl;
          studyLink.replaceChildren(document.createTextNode(isPlaceholder ? 'Explore concept study' : 'View full case study'), arrowIcon());
        } else {
          studyLink.removeAttribute('href');
          studyLink.replaceChildren();
        }
      }
      if (primaryImage) {
        setProjectImage({ src: project.image, alt: project.imageAlt, width: project.imageWidth, height: project.imageHeight }, `${project.title}${isPlaceholder ? ' placeholder' : ''} artwork`);
        primaryImage.style.viewTransitionName = safeStudyUrl(project.caseStudy) && /^project-\d{2}$/.test(project.id)
          ? `study-${project.id}` : 'none';
      }
      const gallery = document.getElementById('dialog-gallery');
      if (gallery) {
        gallery.replaceChildren();
        const extraImages = (project.images || []).map(imageDetails)
          .filter(item => item && item.src && item.src !== project.image);
        // Thumbnails appear only when there are additional images to inspect.
        if (extraImages.length && primaryImage) {
          const images = [{ src: project.image, alt: project.imageAlt, width: project.imageWidth, height: project.imageHeight }, ...extraImages];
          images.forEach((item, index) => {
            const thumbnail = makeElement('button', `gallery-thumbnail${index === 0 ? ' is-active' : ''}`);
            thumbnail.type = 'button';
            thumbnail.setAttribute('aria-label', `View project image ${index + 1}`);
            thumbnail.setAttribute('aria-pressed', String(index === 0));
            if (index === 0) {
              // Keep a way back to the main view without duplicating its image.
              thumbnail.textContent = 'Main image';
            } else {
              const picture = makeElement('img');
              picture.src = item.src;
              picture.alt = '';
              picture.width = 120;
              picture.height = 90;
              picture.loading = 'lazy';
              picture.decoding = 'async';
              thumbnail.append(picture);
            }
            thumbnail.addEventListener('click', () => {
              setProjectImage(item, `${project.title}, image ${index + 1}`);
              gallery.querySelectorAll('button').forEach(button => {
                const selected = button === thumbnail;
                button.classList.toggle('is-active', selected);
                button.setAttribute('aria-pressed', String(selected));
              });
            });
            gallery.append(thumbnail);
          });
        }
        gallery.hidden = !extraImages.length;
      }
      if (!dialog.open) dialog.showModal();
      dialog.scrollTop = 0;
      body.classList.add('modal-open');
      if (closeButton) closeButton.focus({ preventScroll: true });
    };
    if (grid && dialog && typeof dialog.showModal === 'function') {
      grid.addEventListener('click', event => {
        const trigger = event.target.closest('.project-open');
        if (!trigger || !grid.contains(trigger)) return;
        const project = projects.find(item => String(item.id) === trigger.dataset.projectId);
        if (project) showProject(project, trigger);
      });
      if (closeButton) closeButton.addEventListener('click', () => dialog.close());
      let backdropPointerDown = false;
      const outsideDialog = event => {
        const box = dialog.getBoundingClientRect();
        return event.clientX < box.left || event.clientX > box.right ||
          event.clientY < box.top || event.clientY > box.bottom;
      };
      dialog.addEventListener('pointerdown', event => {
        backdropPointerDown = event.target === dialog && outsideDialog(event);
      });
      dialog.addEventListener('click', event => {
        if (backdropPointerDown && event.target === dialog && outsideDialog(event)) dialog.close();
        backdropPointerDown = false;
      });
      dialog.addEventListener('close', () => {
        body.classList.remove('modal-open');
        if (modalTrigger && modalTrigger.isConnected && !modalTrigger.closest('[hidden]')) {
          modalTrigger.focus({ preventScroll: true });
        }
      });
    }

    /* Prepare a draft only. This site has no service that sends or stores enquiries. */
    const form = document.getElementById('contact-form');
    const formStatus = document.getElementById('form-status');
    const draftLink = document.getElementById('email-draft');
    const copyButton = document.getElementById('copy-enquiry');
    let enquiryText = '';
    let copyFallback;
    const setStatus = message => {
      if (formStatus) formStatus.textContent = message;
    };
    if (form) {
      form.action = `mailto:${CONTACT.email}`;
      form.addEventListener('submit', event => {
        event.preventDefault();
        ['name', 'message'].forEach(name => {
          const input = form.elements.namedItem(name);
          if (input) input.setCustomValidity(input.value.trim() ? '' : `Please enter your ${name}.`);
        });
        if (!form.reportValidity()) return;
        const values = new FormData(form);
        const getValue = name => String(values.get(name) || '').trim();
        const role = getValue('role');
        const subject = `Employment opportunity — ${role || 'Graphic Designer / Lead Designer'}`;
        enquiryText = [
          `Hello ${CONTACT.name},`,
          '',
          getValue('message'),
          '',
          `Role / Position: ${role || 'Not specified'}`,
          `Name: ${getValue('name')}`,
          `Email: ${getValue('email')}`,
          `Phone: ${getValue('phone') || 'Not provided'}`,
          `Company: ${getValue('company') || 'Not provided'}`
        ].join('\n');
        const draft = `mailto:${CONTACT.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(enquiryText)}`;
        if (draftLink) {
          draftLink.href = draft;
          draftLink.hidden = false;
        }
        if (copyButton) copyButton.hidden = false;
        if (copyFallback) copyFallback.remove();
        copyFallback = null;
        setStatus('Your email app will open with a draft. Send it there to finish. No message has been sent by this website. If it does not open, use Open email draft or Copy message below.');
        window.location.href = draft;
      });
      form.addEventListener('input', event => {
        if (event.target.name === 'name' || event.target.name === 'message') {
          event.target.setCustomValidity('');
        }
        if (!enquiryText) return;
        enquiryText = '';
        if (draftLink) draftLink.hidden = true;
        if (copyButton) copyButton.hidden = true;
        if (copyFallback) copyFallback.remove();
        copyFallback = null;
        setStatus('Your message has changed. Select Prepare email to create an updated draft.');
      });
    }
    if (copyButton && form) {
      copyButton.addEventListener('click', async () => {
        if (!enquiryText) return;
        try {
          if (!navigator.clipboard || !window.isSecureContext) throw new Error('Clipboard unavailable');
          await navigator.clipboard.writeText(enquiryText);
          setStatus('Message copied. Paste it into an email to ' + CONTACT.email + '. No message has been sent by this website.');
        } catch (_) {
          if (!copyFallback) {
            copyFallback = makeElement('textarea', 'enquiry-copy-output');
            copyFallback.readOnly = true;
            copyFallback.rows = 8;
            copyFallback.setAttribute('aria-label', 'Recruitment message — select and copy to your email app');
            form.append(copyFallback);
          }
          copyFallback.value = enquiryText;
          copyFallback.focus();
          copyFallback.select();
          let copied = false;
          try { copied = document.execCommand('copy'); } catch (_) { /* Manual selection remains available. */ }
          if (copied) {
            copyFallback.remove();
            copyFallback = null;
            copyButton.focus();
            setStatus('Message copied. Paste it into an email to ' + CONTACT.email + '. No message has been sent by this website.');
          } else {
            setStatus('Your message is selected below. Copy it and paste it into your email app, then send it to ' + CONTACT.email + '. No message has been sent by this website.');
          }
        }
      });
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
})();
