/* Local, progressive enhancement for the illustrative concept studies. */
(() => {
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const revealNodes = [...document.querySelectorAll('.study-reveal')];
  let observer;
  function showAll() {
    if (observer) observer.disconnect();
    revealNodes.forEach(node => node.classList.remove('motion-ready'));
  }
  if (!motion.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.06 });
    revealNodes.forEach(node => { node.classList.add('motion-ready'); observer.observe(node); });
  }
  if (motion.addEventListener) motion.addEventListener('change', showAll);
  document.querySelectorAll('[data-comparison]').forEach(comparison => {
    const control = comparison.querySelector('.comparison-control');
    const range = comparison.querySelector('input[type="range"]');
    function update() {
      const value = Math.min(100, Math.max(0, Number(range.value)));
      comparison.style.setProperty('--split', value + '%');
      range.setAttribute('aria-valuetext', value + '% schematic outline, ' + (100-value) + '% digital mockup');
    }
    control.hidden = false;
    range.addEventListener('input', update);
    update();
  });
})();
