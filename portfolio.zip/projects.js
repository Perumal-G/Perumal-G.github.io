/* EDIT PORTFOLIO PROJECTS HERE
 * These entries are illustrative concept mockups, not verified personal or client work.
 * Replace titles, descriptions, details, tools and images with your own verified projects.
 * Valid filter keys: vector, logo, lapel-pin, trophy, packaging, branding, print, social-media, cnc-laser.
 * Preserve a unique id and set placeholder: false only after adding verified work.
 * Local image paths are relative to index.html.
 * ADD NEW PORTFOLIO PROJECT HERE
 */
window.PORTFOLIO_PROJECTS = [
  {
    "id": "project-01",
    "title": "Lapel Pin Design",
    "categories": [
      "lapel-pin",
      "vector"
    ],
    "category": "Product artwork",
    "description": "A gold-and-green enamel pin against textured charcoal wool.",
    "challenge": "A clear silhouette, precise metal outlines and defined colour separations.",
    "solution": "Angular bird wings, forest-green panels and fine warm-gold edges.",
    "software": [
      "Digital concept visualization"
    ],
    "output": "Pin concept mockup; production specifications are not verified.",
    "image": "assets/projects/lapel-pin-mockup.webp",
    "images": [
      "assets/projects/lapel-pin-mockup.webp"
    ],
    "imageAlt": "A geometric bird lapel pin concept with gold edges and green enamel-style panels on charcoal fabric.",
    "placeholder": true,
    "medium": "Enamel pin visualization",
    "featured": true,
    "caseStudy": "studies/lapel-pin.html"
  },
  {
    "id": "project-02",
    "title": "Trophy & Award Design",
    "categories": [
      "trophy",
      "vector"
    ],
    "category": "Recognition design",
    "description": "A supplied crystal award image, with a wood-and-crystal concept as a second view.",
    "challenge": "Inscription hierarchy, etched motifs and material presentation.",
    "solution": "A personalised crystal award visual alongside a walnut-and-crystal concept.",
    "software": [
      "Supplied award visual",
      "Product concept visualization"
    ],
    "output": "Supplied crystal award visual and a secondary wood-and-crystal concept mockup.",
    "image": "assets/projects/award-user.webp",
    "images": [
      "assets/projects/award-user.webp",
      {
        "src": "assets/projects/award-mockup.webp",
        "alt": "Wood-and-crystal trophy concept with a walnut base and backing.",
        "width": 1448,
        "height": 1086
      }
    ],
    "imageAlt": "User-supplied clear crystal award image bearing Perumal G’s name above a dark base.",
    "placeholder": true,
    "medium": "Crystal & wood/crystal award visuals",
    "imageWidth": 3400,
    "imageHeight": 3000
  },
  {
    "id": "project-03",
    "title": "Vector Illustration",
    "categories": [
      "vector"
    ],
    "category": "Vector study",
    "description": "Botanical artwork presented as a carefully framed print.",
    "challenge": "Fine detail, quiet spacing and clear artwork reproduction.",
    "solution": "An olive branch on ivory paper, presented in a thin black frame.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Framed artwork concept; editable production files are not supplied.",
    "image": "assets/projects/art-print-mockup.webp",
    "images": [
      "assets/projects/art-print-mockup.webp"
    ],
    "imageAlt": "A botanical olive-branch print in a regular rectangular black frame.",
    "placeholder": true,
    "medium": "Framed print"
  },
  {
    "id": "project-04",
    "title": "Packaging Design",
    "categories": [
      "packaging",
      "print",
      "vector"
    ],
    "category": "Packaging & print",
    "description": "Botanical tea packaging in forest green and warm ivory.",
    "challenge": "Clear label hierarchy, straight folds and coordinated surfaces.",
    "solution": "A rectangular carton with an ivory botanical label and a matching card.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Packaging concept mockup; dielines and production specifications are not verified.",
    "image": "assets/projects/packaging-mockup.webp",
    "images": [
      "assets/projects/packaging-mockup.webp"
    ],
    "imageAlt": "A forest-green Botanical Tea carton with an ivory label and matching card.",
    "placeholder": true,
    "medium": "Carton & label concept",
    "featured": true,
    "caseStudy": "studies/packaging.html"
  },
  {
    "id": "project-05",
    "title": "Brand Identity",
    "categories": [
      "branding",
      "print"
    ],
    "category": "Visual identity",
    "description": "A coordinated identity across textured paper and business cards.",
    "challenge": "A consistent monogram, measured spacing and material contrast.",
    "solution": "A warm-gold PG monogram across ivory letterhead and forest-green cards.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Stationery concept mockups; these are not commissioned client materials.",
    "image": "assets/projects/stationery-mockup.webp",
    "images": [
      "assets/projects/stationery-mockup.webp"
    ],
    "imageAlt": "Ivory letterhead and forest-green business cards with a gold PG monogram.",
    "placeholder": true,
    "medium": "Stationery system"
  },
  {
    "id": "project-06",
    "title": "Print Production",
    "categories": [
      "print"
    ],
    "category": "Print & prepress",
    "description": "A folded botanical brochure alongside a colour-proof sheet.",
    "challenge": "Page hierarchy, fold placement and print preparation.",
    "solution": "Ivory paper, restrained green layouts, colour patches and registration marks.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Print concept visualization; press specifications and printed output are not verified.",
    "image": "assets/projects/print-mockup.webp",
    "images": [
      "assets/projects/print-mockup.webp"
    ],
    "imageAlt": "An open botanical Print Study brochure above a sheet with colour patches and crop marks.",
    "placeholder": true,
    "medium": "Brochure & proof study"
  },
  {
    "id": "project-07",
    "title": "Logo Design",
    "categories": [
      "logo",
      "branding",
      "vector"
    ],
    "category": "Identity exploration",
    "description": "PERU: a confident wordmark built from four uppercase letters.",
    "challenge": "Balanced letterforms, clear readability and consistent applications.",
    "solution": "Custom PERU lettering in warm-gold foil on forest green and blind embossing on ivory.",
    "software": [
      "Product concept visualization"
    ],
    "output": "PERU identity concept mockups; these are not a verified client identity.",
    "image": "assets/projects/logo-mockup.webp",
    "images": [
      "assets/projects/logo-mockup.webp"
    ],
    "imageAlt": "Matching PERU wordmark logos on foil-stamped forest-green and embossed ivory cards.",
    "placeholder": true,
    "medium": "PERU wordmark & applications"
  },
  {
    "id": "project-08",
    "title": "CNC & Laser Artwork",
    "categories": [
      "cnc-laser",
      "vector"
    ],
    "category": "Production artwork",
    "description": "A regular brass panel with a clean, repeating cut pattern.",
    "challenge": "Consistent openings, connected bridges and a stable outer frame.",
    "solution": "Circular openings arranged within a straight rectangular satin-brass panel.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Cut-panel concept visualization; material, tolerances and toolpaths are not verified.",
    "image": "assets/projects/laser-panel-mockup.webp",
    "images": [
      "assets/projects/laser-panel-mockup.webp"
    ],
    "imageAlt": "A rectangular satin-brass laser-cut panel concept with regular circular openings.",
    "placeholder": true,
    "medium": "Laser-cut panel concept",
    "featured": true,
    "caseStudy": "studies/cnc-laser.html"
  },
  {
    "id": "project-09",
    "title": "Social Media Design",
    "categories": [
      "social-media",
      "branding"
    ],
    "category": "Digital graphics",
    "description": "One campaign direction adapted for screen and print.",
    "challenge": "Readable typography, clear hierarchy and consistency across formats.",
    "solution": "An ivory headline on forest green, shown on a phone and a square card.",
    "software": [
      "Product concept visualization"
    ],
    "output": "Social graphic concept mockup; this is not a published campaign.",
    "image": "assets/projects/social-mockup.webp",
    "images": [
      "assets/projects/social-mockup.webp"
    ],
    "imageAlt": "A phone and square card displaying the forest-green Make Ideas Matter graphic.",
    "placeholder": true,
    "medium": "Screen & print layout"
  }
];
