/* Small, event-driven depth effects. No canvas, sensors, dependencies or idle render loop. */
(() => {
  'use strict';

  const initialize = () => {
    const visual = document.querySelector('.hero-visual');
    const scene = visual && visual.querySelector('.hero-depth-scene');
    const header = document.querySelector('.site-header');
    const grid = document.getElementById('project-grid');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
    const layers = scene ? [...scene.querySelectorAll('[data-depth]')].map(element => {
      const value = Number(element.dataset.depth);
      return { element, depth: Number.isFinite(value) ? Math.max(-1.5, Math.min(1.5, value)) : 0 };
    }) : [];
    const cards = new Map();
    const movingCards = new Set();
    const movingCursors = new Set();
    const magnets = new Map();
    const movingMagnets = new Set();
    const passive = { passive: true };
    const clamp = (value, limit = 1) => Math.max(-limit, Math.min(limit, value));
    const settle = (current, target, amount) => {
      const next = current + (target - current) * amount;
      return Math.abs(target - next) < 0.0007 ? target : next;
    };
    const hero = {
      x: 0, y: 0, targetX: 0, targetY: 0, visible: true,
      light: 0, targetLight: 0, bounds: null, pointer: null, moving: false
    };
    let mode = 'reduced';
    let frame = 0;
    let previousTime = 0;
    let layoutPending = false;
    let headerScrolled = null;
    let filterEventActive = false;

    const setHero = () => {
      const pointerMode = mode === 'pointer';
      if (visual) {
        visual.style.setProperty('--light-x', `${pointerMode ? 50 + hero.x * 20 : 50}%`);
        visual.style.setProperty('--light-y', `${pointerMode ? 50 + hero.y * 16 : 50}%`);
        visual.style.setProperty('--light-opacity', `${pointerMode ? hero.light : 0}`);
      }
      if (!scene) return;
      scene.style.setProperty('--scene-rx', `${pointerMode ? -hero.y * 2 : 0}deg`);
      scene.style.setProperty('--scene-ry', `${pointerMode ? hero.x * 3 : 0}deg`);
      layers.forEach(({ element, depth }) => {
        element.style.setProperty('--depth-x', `${pointerMode ? hero.x * depth * 10 : 0}px`);
        element.style.setProperty('--depth-y', `${hero.y * depth * (pointerMode ? 8 : 4)}px`);
      });
    };
    const setCard = state => {
      state.element.style.setProperty('--card-rx', `${-state.y * 1.5}deg`);
      state.element.style.setProperty('--card-ry', `${state.x * 2}deg`);
      state.element.style.setProperty('--card-glow-x', `${50 + state.x * 42}%`);
      state.element.style.setProperty('--card-glow-y', `${50 + state.y * 42}%`);
      if (state.imageWrap) {
        state.imageWrap.style.setProperty('--art-x', `${state.x * 2}px`);
        state.imageWrap.style.setProperty('--art-y', `${state.y * 2}px`);
      }
    };
    const setCursor = state => {
      if (!state.imageWrap) return;
      state.imageWrap.style.setProperty('--cursor-x', `${state.cursorX}px`);
      state.imageWrap.style.setProperty('--cursor-y', `${state.cursorY}px`);
    };
    const setMagnet = state => {
      state.element.style.setProperty('--magnet-x', `${state.x * 3}px`);
      state.element.style.setProperty('--magnet-y', `${state.y * 2}px`);
    };
    const updateAmbient = () => {
      if (visual) visual.classList.toggle('is-ambient-running',
        !!scene && hero.visible && !document.hidden && !reduced.matches);
    };
    const updateHeader = () => {
      if (!header) return;
      const scrolled = window.scrollY > 32;
      if (scrolled === headerScrolled) return;
      headerScrolled = scrolled;
      header.classList.toggle('is-scrolled', scrolled);
    };
    const hasWork = () => layoutPending || hero.moving || movingCards.size > 0 ||
      movingCursors.size > 0 || movingMagnets.size > 0;
    const queue = () => {
      if (frame || document.hidden || !hasWork()) return;
      frame = window.requestAnimationFrame(update);
    };
    const stopWhenIdle = () => {
      if (hasWork()) return;
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
      previousTime = 0;
    };
    const resetHero = immediate => {
      hero.targetX = 0;
      hero.targetY = 0;
      hero.targetLight = 0;
      hero.pointer = null;
      if (immediate) {
        hero.x = 0;
        hero.y = 0;
        hero.light = 0;
        hero.moving = false;
        if (visual) visual.classList.remove('is-motion-active');
        setHero();
        stopWhenIdle();
      } else {
        hero.moving = hero.x !== 0 || hero.y !== 0 || hero.light !== 0;
        if (hero.moving && visual) visual.classList.add('is-motion-active');
        queue();
      }
    };
    const resetCursor = (state, immediate) => {
      state.imagePointer = null;
      if (state.imageWrap) state.imageWrap.classList.remove('is-cursor-active');
      movingCursors.delete(state);
      if (immediate) {
        state.cursorX = 0;
        state.cursorY = 0;
        state.cursorTargetX = 0;
        state.cursorTargetY = 0;
        setCursor(state);
      }
      stopWhenIdle();
    };
    const resetCard = (state, immediate) => {
      resetCursor(state, immediate);
      state.targetX = 0;
      state.targetY = 0;
      state.pointer = null;
      state.entered = false;
      if (immediate || (state.x === 0 && state.y === 0)) {
        state.x = 0;
        state.y = 0;
        setCard(state);
        movingCards.delete(state);
        state.element.classList.remove('is-pointer-active');
        stopWhenIdle();
      } else {
        movingCards.add(state);
        queue();
      }
    };
    const resetMagnet = (state, immediate) => {
      state.targetX = 0;
      state.targetY = 0;
      state.pointer = null;
      if (immediate || (state.x === 0 && state.y === 0)) {
        state.x = 0;
        state.y = 0;
        setMagnet(state);
        movingMagnets.delete(state);
        stopWhenIdle();
      } else {
        movingMagnets.add(state);
        queue();
      }
    };
    const resetAll = immediate => {
      resetHero(immediate);
      cards.forEach(state => resetCard(state, immediate));
      magnets.forEach(state => resetMagnet(state, immediate));
    };
    const heroBounds = () => {
      if (!hero.bounds && visual) hero.bounds = visual.getBoundingClientRect();
      return hero.bounds;
    };
    const cardBounds = state => {
      if (!state.bounds) state.bounds = state.element.getBoundingClientRect();
      return state.bounds;
    };
    const imageBounds = state => {
      if (!state.imageBounds && state.imageWrap) state.imageBounds = state.imageWrap.getBoundingClientRect();
      return state.imageBounds;
    };
    const filtering = () => filterEventActive || !!(grid && grid.classList.contains('is-filtering'));
    const cardAvailable = state => !filtering() && state.visible && !state.element.hidden &&
      state.element.isConnected && !(state.trigger && state.trigger.matches(':focus-visible'));
    const eligible = event => mode === 'pointer' && event.pointerType === 'mouse' &&
      !document.hidden && !document.body.classList.contains('modal-open');
    const trackHero = event => {
      if (!eligible(event) || !scene || !hero.visible) return;
      const box = heroBounds();
      if (!box || !box.width || !box.height) return;
      hero.pointer = { x: event.clientX, y: event.clientY };
      hero.targetX = clamp((event.clientX - box.left) / box.width * 2 - 1);
      hero.targetY = clamp((event.clientY - box.top) / box.height * 2 - 1);
      hero.targetLight = 1;
      hero.moving = true;
      visual.classList.add('is-motion-active');
      queue();
    };
    const trackCard = (state, event) => {
      if (!eligible(event) || !cardAvailable(state)) return;
      const box = cardBounds(state);
      if (!box.width || !box.height) return;
      state.pointer = { x: event.clientX, y: event.clientY };
      state.targetX = clamp((event.clientX - box.left) / box.width * 2 - 1);
      state.targetY = clamp((event.clientY - box.top) / box.height * 2 - 1);
      state.entered = true;
      state.element.classList.add('is-pointer-active');
      movingCards.add(state);
      queue();
    };
    const trackCursor = (state, event) => {
      if (!eligible(event) || !cardAvailable(state) || !state.imageWrap) return;
      const box = imageBounds(state);
      if (!box || !box.width || !box.height) return;
      const wasActive = !!state.imagePointer;
      state.imagePointer = { x: event.clientX, y: event.clientY };
      // Keep the small label inside the artwork, including at the image edges.
      const insetX = Math.min(28, box.width / 2);
      const insetY = Math.min(28, box.height / 2);
      state.cursorTargetX = Math.max(insetX, Math.min(box.width - insetX, event.clientX - box.left));
      state.cursorTargetY = Math.max(insetY, Math.min(box.height - insetY, event.clientY - box.top));
      if (!wasActive) {
        state.cursorX = state.cursorTargetX;
        state.cursorY = state.cursorTargetY;
        setCursor(state);
      }
      state.imageWrap.classList.add('is-cursor-active');
      movingCursors.add(state);
      queue();
    };
    const trackMagnet = (state, event) => {
      if (!eligible(event) || !state.visible || state.element.matches(':focus-visible')) return;
      const box = cardBounds(state);
      if (!box.width || !box.height) return;
      state.pointer = { x: event.clientX, y: event.clientY };
      state.targetX = clamp((event.clientX - box.left) / box.width * 2 - 1);
      state.targetY = clamp((event.clientY - box.top) / box.height * 2 - 1);
      movingMagnets.add(state);
      queue();
    };
    const updateScrollDepth = () => {
      if (mode !== 'scroll' || !scene || !hero.visible || document.hidden) return;
      const box = heroBounds();
      if (!box || !box.height) return;
      // A few pixels of depth follow reading progress; touch and scrolling stay native.
      hero.targetX = 0;
      hero.targetLight = 0;
      hero.targetY = clamp((window.innerHeight / 2 - box.top - box.height / 2) /
        (window.innerHeight / 2 + box.height / 2));
      hero.moving = hero.x !== hero.targetX || hero.y !== hero.targetY;
      if (hero.moving) visual.classList.add('is-motion-active');
      queue();
    };
    const invalidate = () => {
      hero.bounds = null;
      cards.forEach(state => { state.bounds = null; state.imageBounds = null; });
      magnets.forEach(state => { state.bounds = null; });
    };
    const pointerStillInside = (pointer, box) => pointer && box &&
      pointer.x >= box.left && pointer.x <= box.right &&
      pointer.y >= box.top && pointer.y <= box.bottom;
    const refreshLayout = () => {
      invalidate();
      updateHeader();
      if (mode === 'scroll') updateScrollDepth();
      else if (mode === 'pointer') {
        if (hero.pointer) {
          if (pointerStillInside(hero.pointer, heroBounds())) {
            trackHero({ pointerType: 'mouse', clientX: hero.pointer.x, clientY: hero.pointer.y });
          } else resetHero(false);
        }
        cards.forEach(state => {
          if (!cardAvailable(state)) resetCard(state, true);
          else if (state.pointer) {
            if (pointerStillInside(state.pointer, cardBounds(state))) {
              trackCard(state, { pointerType: 'mouse', clientX: state.pointer.x, clientY: state.pointer.y });
            } else resetCard(state, false);
          }
          if (state.imagePointer) {
            if (pointerStillInside(state.imagePointer, imageBounds(state))) {
              trackCursor(state, { pointerType: 'mouse', clientX: state.imagePointer.x, clientY: state.imagePointer.y });
            } else resetCursor(state, false);
          }
        });
        magnets.forEach(state => {
          if (!state.element.isConnected || state.element.hidden) resetMagnet(state, true);
          else if (state.pointer) {
            if (pointerStillInside(state.pointer, cardBounds(state))) {
              trackMagnet(state, { pointerType: 'mouse', clientX: state.pointer.x, clientY: state.pointer.y });
            } else resetMagnet(state, false);
          }
        });
      }
    };
    const layoutChanged = () => {
      layoutPending = true;
      queue();
    };

    // One scheduler batches layout events and stops as soon as positions settle.
    function update(time) {
      frame = 0;
      if (document.hidden) {
        layoutPending = false;
        resetAll(true);
        return;
      }
      if (layoutPending) {
        layoutPending = false;
        refreshLayout();
      }
      if (mode === 'reduced') {
        resetAll(true);
        previousTime = 0;
        return;
      }
      const elapsed = previousTime ? Math.min(64, time - previousTime) : 16.67;
      previousTime = time;
      if (hero.moving) {
        if (!hero.visible) resetHero(true);
        else {
          const amount = 1 - Math.exp(-elapsed / 125);
          hero.x = settle(hero.x, hero.targetX, amount);
          hero.y = settle(hero.y, hero.targetY, amount);
          hero.light = settle(hero.light, hero.targetLight, amount);
          setHero();
          hero.moving = hero.x !== hero.targetX || hero.y !== hero.targetY || hero.light !== hero.targetLight;
          if (!hero.moving && visual) visual.classList.remove('is-motion-active');
        }
      }
      movingCards.forEach(state => {
        if (!cardAvailable(state)) {
          resetCard(state, true);
          return;
        }
        const amount = 1 - Math.exp(-elapsed / 95);
        state.x = settle(state.x, state.targetX, amount);
        state.y = settle(state.y, state.targetY, amount);
        setCard(state);
        if (state.x === state.targetX && state.y === state.targetY) {
          movingCards.delete(state);
          if (!state.entered) state.element.classList.remove('is-pointer-active');
        }
      });
      movingCursors.forEach(state => {
        if (!cardAvailable(state) || !state.imagePointer) {
          resetCursor(state, true);
          return;
        }
        const amount = 1 - Math.exp(-elapsed / 90);
        state.cursorX = settle(state.cursorX, state.cursorTargetX, amount);
        state.cursorY = settle(state.cursorY, state.cursorTargetY, amount);
        setCursor(state);
        if (state.cursorX === state.cursorTargetX && state.cursorY === state.cursorTargetY) movingCursors.delete(state);
      });
      movingMagnets.forEach(state => {
        if (!state.visible || state.element.hidden || !state.element.isConnected ||
          state.element.matches(':focus-visible')) {
          resetMagnet(state, true);
          return;
        }
        const amount = 1 - Math.exp(-elapsed / 105);
        state.x = settle(state.x, state.targetX, amount);
        state.y = settle(state.y, state.targetY, amount);
        setMagnet(state);
        if (state.x === state.targetX && state.y === state.targetY) movingMagnets.delete(state);
      });
      if (hasWork()) queue();
      else previousTime = 0;
    }

    const intersection = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.target === visual) {
          hero.visible = entry.isIntersecting;
          updateAmbient();
          if (!hero.visible) resetHero(true);
          else if (mode === 'scroll') updateScrollDepth();
        } else {
          const state = cards.get(entry.target) || magnets.get(entry.target);
          if (!state) return;
          state.visible = entry.isIntersecting;
          if (!state.visible) {
            if (magnets.has(entry.target)) resetMagnet(state, true);
            else resetCard(state, true);
          }
        }
      });
    }, { threshold: 0 }) : null;

    const addCards = () => {
      if (!grid) return;
      cards.forEach((state, element) => {
        if (grid.contains(element)) return;
        resetCard(state, true);
        if (intersection) intersection.unobserve(element);
        cards.delete(element);
      });
      grid.querySelectorAll('.project-card').forEach(element => {
        if (cards.has(element)) return;
        const imageWrap = element.querySelector('.project-image-wrap');
        if (imageWrap && !imageWrap.querySelector('.project-view-cursor')) {
          const cursor = document.createElement('span');
          cursor.className = 'project-view-cursor';
          cursor.textContent = 'VIEW';
          cursor.setAttribute('aria-hidden', 'true');
          imageWrap.append(cursor);
        }
        const state = {
          element, x: 0, y: 0, targetX: 0, targetY: 0,
          entered: false, visible: true, bounds: null, pointer: null,
          trigger: element.querySelector('.project-open'), imageWrap, imageBounds: null,
          imagePointer: null, cursorX: 0, cursorY: 0, cursorTargetX: 0, cursorTargetY: 0
        };
        cards.set(element, state);
        setCard(state);
        setCursor(state);
        element.addEventListener('pointerenter', event => trackCard(state, event), passive);
        element.addEventListener('pointermove', event => trackCard(state, event), passive);
        element.addEventListener('pointerleave', () => resetCard(state, false), passive);
        element.addEventListener('pointercancel', () => resetCard(state, false), passive);
        element.addEventListener('click', () => resetCard(state, false), passive);
        element.addEventListener('focusin', () => resetCard(state, true));
        if (imageWrap) {
          imageWrap.addEventListener('pointerenter', event => trackCursor(state, event), passive);
          imageWrap.addEventListener('pointermove', event => trackCursor(state, event), passive);
          imageWrap.addEventListener('pointerleave', () => resetCursor(state, false), passive);
          imageWrap.addEventListener('pointercancel', () => resetCursor(state, true), passive);
        }
        if (intersection) intersection.observe(element);
      });
    };
    const updateMode = () => {
      mode = reduced.matches ? 'reduced' : finePointer.matches ? 'pointer' : 'scroll';
      resetAll(true);
      invalidate();
      if (visual) visual.dataset.motionMode = mode;
      updateAmbient();
      if (mode === 'scroll') updateScrollDepth();
    };
    const watchMedia = query => {
      if (query.addEventListener) query.addEventListener('change', updateMode);
      else query.addListener(updateMode);
    };

    if (scene) {
      visual.addEventListener('pointerenter', trackHero, passive);
      visual.addEventListener('pointermove', trackHero, passive);
      visual.addEventListener('pointerleave', () => resetHero(false), passive);
      visual.addEventListener('pointercancel', () => resetHero(false), passive);
      if (intersection) intersection.observe(visual);
    }
    document.querySelectorAll('.hero-copy .button, .hero-conversation').forEach(element => {
      const state = {
        element, x: 0, y: 0, targetX: 0, targetY: 0,
        visible: true, bounds: null, pointer: null
      };
      magnets.set(element, state);
      setMagnet(state);
      element.addEventListener('pointerenter', event => trackMagnet(state, event), passive);
      element.addEventListener('pointermove', event => trackMagnet(state, event), passive);
      element.addEventListener('pointerleave', () => resetMagnet(state, false), passive);
      element.addEventListener('pointercancel', () => resetMagnet(state, false), passive);
      element.addEventListener('focus', () => resetMagnet(state, true));
      element.addEventListener('click', () => resetMagnet(state, false), passive);
      if (intersection) intersection.observe(element);
    });
    addCards();
    if (grid && 'MutationObserver' in window) {
      new MutationObserver(records => {
        const added = records.some(record => record.type === 'childList');
        const layoutChange = added || records.some(record => record.attributeName === 'hidden' ||
          (record.attributeName === 'class' && record.target === grid));
        if (!layoutChange) return;
        // Ignore the pointer classes written above; their mutations do not change layout.
        if (added) addCards();
        if (filtering()) cards.forEach(state => resetCard(state, true));
        layoutChanged();
      }).observe(grid, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden', 'class'] });
    }
    document.addEventListener('portfolio:filterstart', () => {
      filterEventActive = true;
      cards.forEach(state => resetCard(state, true));
      invalidate();
    });
    document.addEventListener('portfolio:filterend', () => {
      filterEventActive = false;
      layoutChanged();
    });
    if ('ResizeObserver' in window) {
      const resize = new ResizeObserver(layoutChanged);
      if (visual) resize.observe(visual);
      if (grid) resize.observe(grid);
      magnets.forEach(state => resize.observe(state.element));
    }
    window.addEventListener('scroll', layoutChanged, passive);
    window.addEventListener('resize', layoutChanged, passive);
    window.addEventListener('blur', () => resetAll(true), passive);
    document.addEventListener('visibilitychange', () => {
      updateAmbient();
      if (document.hidden) {
        layoutPending = false;
        resetAll(true);
      }
      else layoutChanged();
    });
    // Hybrid devices must never tilt a card or intercept a gesture during touch input.
    document.addEventListener('pointerdown', event => {
      if (event.pointerType !== 'mouse') resetAll(true);
    }, passive);
    document.addEventListener('keydown', event => {
      if (event.key === 'Tab' || event.key === 'Escape') resetAll(true);
    });
    watchMedia(reduced);
    watchMedia(finePointer);
    updateHeader();
    updateMode();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else initialize();
})();
